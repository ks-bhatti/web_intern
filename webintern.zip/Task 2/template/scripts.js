document.addEventListener('DOMContentLoaded', function () {
    const passwordField = document.getElementById('password');
    const capsWarning = document.querySelector('.caps-warning');

    passwordField.addEventListener('keyup', function (event) {
        if (event.getModifierState('CapsLock')) {
            capsWarning.style.display = 'block';
        } else {
            capsWarning.style.display = 'none';
        }
    });
});
